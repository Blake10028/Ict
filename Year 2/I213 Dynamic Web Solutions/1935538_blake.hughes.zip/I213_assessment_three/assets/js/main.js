document.addEventListener("DOMContentLoaded", function () {
    w3.getHttpObject("/cars", displayCars);
    w3.getHttpObject("/cars/make-menu", displayMakeMenu);

    const model = "";
});

async function displayCars(cars) {
    let carData = {"cars": cars};
    
    await w3.displayObject("cars", carData);
    w3.removeClass("#cars", "w3-hide");
    return;
}

async function displayMakeMenu(makes) {
    makeData = { make: makes };
    await w3.displayObject("makes-dropdown" , makeData);
}

async function filterByMake(e) {
    w3.addClass("#year-dropdown", "w3-hide");
    let value = e.target.textContent;
    await w3.getHttpObject(`cars/?make=${value}`, displayCars);
    await w3.getHttpObject(`/cars/model-menu/?make=${value}`, displayModelMenu);
}

async function displayModelMenu(models) {
   modelData = { model: models };
   await w3.displayObject("models-dropdown", modelData);
    w3.removeClass("#models-dropdown", "w3-hide");
}

async function filterByModel(e) {
    let value = e.target.textContent;
    model = value;
    value = value.replace(" ", "_");
    await w3.getHttpObject(`cars/?model=${value}`, displayCars);
    await w3.getHttpObject(`/cars/year-menu/?model=${value}`, displayYearMenu);
}

async function displayYearMenu(years) {
    yearData = { year: years };
    await w3.displayObject("year-dropdown", yearData);
    w3.removeClass("#year-dropdown", "w3-hide");
}

async function filterByYear(e) {
    let value = e.target.textContent;
    year = value;
    model = model.replace(" ", "_");
    await w3.getHttpObject(`/cars/?model=${model}`);
    await w3.getHttpObject(`/cars/?year=${value}` , displayCars);
}
