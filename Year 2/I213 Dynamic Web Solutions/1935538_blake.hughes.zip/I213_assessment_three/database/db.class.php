<?php
class DB
{
    protected $db;

    public function __construct()
    {
        $this->db = new SQLite3('database/car_sales.db', SQLITE3_OPEN_CREATE | SQLITE3_OPEN_READWRITE);
    }

    /* For basic queries e.g. "SELECT * FROM customers" */
    protected function findAll($sql=null)
    {
        $results = $this->db->query($sql);
        $this->outputNestedObject($results);
    }

    /* For retreiving a single record e.g. "SELECT * FROM customers WHERE id = 2" */
    protected function findOne($sql=null,$id=null)
    {
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':id', $id, SQLITE3_TEXT);
        $results = $stmt->execute();
        $this->outputPlainObject($results);
    }

    /* For more complex queries with mulitiple search parameters e.g. 
        "SELECT * FROM customers WHERE id = 2 AND age = 33". 
        The $arr variable holds an array of $_GET or $_POST values, that get iterated over and bound to place holders set in your $sql query, created in a Controller.
    */
    protected function find($sql=null, $arr=null)
    {
        $stmt = $this->db->prepare($sql);
        foreach ($arr as $key => $value) {
            $stmt->bindValue(":$key", $value, SQLITE3_TEXT);
        }
        $results = $stmt->execute();
        $this->outputNestedObject($results);
    }

    protected function insert($sql=null, $arr=null)
    {
        $stmt = $this->db->prepare($sql);
        foreach($arr as $key => $value) {
            $stmt->bindValue(":$key", $value, SQLITE3_TEXT);
        }
        $result = $stmt->execute();
        if ($result == false) {
            $_SESSION["error_message"] = $this->db->lastErrorMsg();
        } 
        else {
            echo "OK";
        }
    }

    protected function update($sql=null, $arr=null)
    {
        $stmt = $this->db->prepare($sql);
        foreach ($arr as $key => $value) {
            $stmt->bindValue(":$key", $value, SQLITE3_TEXT);
        }
        $result = $stmt->execute();
        if ($result == false) {
            $_SESSION["error_message"] = $this->db->lastErrorMsg();
        } 
        else {
            echo "OK";
        }
    }

    protected function delete($sql=null, $id=null)
    {
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':id', $id, SQLITE3_TEXT);
        $stmt->execute();
    }

    protected function outputPlainObject($result)
    {
        while ($res = $result->fetchArray(SQLITE3_ASSOC)) {
            echo json_encode($res);
        }
        exit();
    }

    protected function outputNestedObject($result)
    {
        $data = array();
        while ($res = $result->fetchArray(1)) {
            array_push($data, $res);
        }
        echo json_encode($data);
        exit();
    }
}
