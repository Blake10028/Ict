<?php
require_once 'config/config.php';

$request = $_SERVER['REQUEST_URI'];

switch ($request) {
    case '/':
        require 'views/index.php';
        break;
        
    case '/cars':
        $car_controller = new CarController();
        $car_controller->index();
        break;

    case '/cars/make-menu':
        $car_controller = new CarController();
        $car_controller->makes();
        break;
    
    case '/cars/?make=' . $_GET['make']:
        $_GET['make'] = removeUnderscore($_GET['make']);
        $car_controller = new CarController();
        $car_controller->carsByMake($_GET);
        break;

    case '/cars/model-menu/?make=' . $_GET['make']:
        $_GET['make'] = removeUnderscore($_GET['make']);
        $car_controller = new CarController();
         $car_controller->models($_GET);
         break;

    
    case '/cars/?model=' . $_GET['model']:
        $_GET['model'] = removeUnderscore($_GET['model']);
        $car_controller = new CarController();
        $car_controller->carsByModel($_GET);
        break;

    case '/cars/year-menu/?model=' . $_GET['model']:
        $_GET['model'] = removeUnderscore($_GET['model']);
        $car_controller = new CarController();
         $car_controller->years($_GET);
         break;


    case '/cars/model-by-year/?model=' . $_GET['model'] . '&year=' . $_GET['year']:
        $_GET['model'] && $_GET['year'];
        $car_controller = new CarController();
        $car_controller->carsByModelAndYear($_GET);
        break;

    

    default:
        require 'views/404.html';
        break;
}

function removeUnderscore($str){
$str = str_replace("_", " ", $str);
return $str;
}