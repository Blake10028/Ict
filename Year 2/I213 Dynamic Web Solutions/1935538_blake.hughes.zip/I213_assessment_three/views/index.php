<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <title>I213 Dynamic Web Solutions Assignment (Part One)</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
  <link rel="stylesheet" href="/assets/css/styles.css" />
</head>

<body>
  <nav id="top-nav">
    <div class="w3-bar w3-blue-gray">
      <a href="#" class="w3-bar-item w3-button">I213 Dynamic Web Solutions (Part One)</a>
    </div>
  </nav>
  <div class="container">
    <header class="main w3-padding">
    </header>
    <section class="bar">
      <div class="w3-bar w3-white w3-margin-top">
        <div class="w3-container">
          <div class="w3-dropdown-hover w3-blue-gray w3-margin-right">
            <button class="w3-button">Make</button>
            <div id="makes-dropdown" class="w3-dropdown-content w3-bar-block w3-border">
              <a href="#" class="w3-bar-item w3-button" w3-repeat="make" onclick="filterByMake(event)">{{make}}</a>
            </div>
          </div>
          <div id="models-dropdown" class="w3-dropdown-hover w3-blue-gray w3-hide w3-margin-right">
            <button class="w3-button">Model</button>
            <div class="w3-dropdown-content w3-bar-block w3-border">
              <a href="#" class="w3-bar-item w3-button" w3-repeat="model" onclick="filterByModel(event)">{{model}}</a>
            </div>
          </div>
          <div id="year-dropdown" class="w3-dropdown-hover w3-blue-gray w3-margin-right w3-hide">
            <button class="w3-button">Year</button>
            <div class="w3-dropdown-content w3-bar-block w3-border">
              <a href="#" class="w3-bar-item w3-button" w3-repeat="year" onclick="filterByYear(event)">{{year}}</a>
            </div>
          </div>

          <button class="w3-button w3-grey w3-right"
            onclick="w3.filterHTML('#cars', 'div', this.textContent)">grey</button>
          <button class="w3-button w3-white w3-right  w3-margin-right w3-border"
            onclick="w3.filterHTML('#cars', 'div', this.textContent)">white</button>
          <button class="w3-button w3-red w3-right  w3-margin-right"
            onclick="w3.filterHTML('#cars', 'div', this.textContent)">red</button>
          <button class="w3-button w3-blue w3-right w3-margin-right"
            onclick="w3.filterHTML('#cars', 'div', this.textContent)">blue</button>
        </div>

    </section>
    <section class="main w3-container">
      <div id="cars" class="cars-grid w3-hide">
        <div class="w3-card relative" w3-repeat="cars">
          <header
            style="height:165px;background-image: url(assets/images/cars/{{image}}.png);background-position: center;background-size: contain;background-repeat: no-repeat;">
          </header>
          <div class="w3-container">
            <p> {{make}} - {{model}} - {{year}} - {{colour}}</p>
            <span class="w3-tag w3-tiny w3-padding w3-green absolute"
              style="transform:rotate(-10deg);  position: absolute; top:25px; right:10px">
              ${{price}} 
            </span>
          </div>
        </div>
      </div>
    </section>
    <footer class="main">
      <div class="w3-bar  w3-blue-gray">
        <div class="w3-bar-item">Created by: Blake Hughes</div>
      </div>
    </footer>
  </div>
  <script src="https://www.w3schools.com/lib/w3.js"></script>
  <script src="/assets/js/main.js"></script>
</body>

</html>