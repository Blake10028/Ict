<?php
include_once("controllers/car.php");

if(!isset($_GET['make'])) {
    $_GET['make'] = null;
}

if(!isset($_GET['model'])) {
    $_GET['model'] = null;
}

if(!isset($_GET['year'])) {
    $_GET['year'] = null;
}