<?php
require_once 'database/db.class.php';

class CarController extends DB
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $sql = 'SELECT * FROM cars ORDER BY random()';
        $this->findAll($sql);
    }

    public function makes()
    {
        $sql = 'SELECT distinct make FROM cars ORDER BY make ASC';
        $this->findAll($sql);

    }

    public function carsByMake($make)
    {
        $sql = 'SELECT * FROM cars Where make = :make ORDER BY random()';
        $this->find($sql, $make);
    }

    public function models($make)
    {
        $sql = 'SELECT distinct model FROM cars where make = :make ORDER BY model ASC';
        $this->find($sql, $make);
    }

    public function carsByModel($model)
    {
        $sql = 'SELECT * FROM cars Where model = :model ORDER BY random()';
        $this->find($sql, $model);
    }

    public function years($model)
    {
        $sql = 'SELECT distinct year FROM cars where model = :model ORDER BY year ASC';
        $this->find($sql, $model);
    }

    public function carsByModelAndYear($get_array)
    {
        $sql = 'SELECT * FROM model Where year = :year ORDER BY year()';
        $this->find($sql,$get_array);
    }
    
}
