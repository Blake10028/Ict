<?php
require_once __DIR__.'/routes/main-router.php';