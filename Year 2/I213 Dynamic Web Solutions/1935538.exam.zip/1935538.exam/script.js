async function login(e) {
    e.preventDefault()

let response =  await fetch("/controller.php", {
method: 'POST',
body: new FormData(loginForm)
});

let result = await response.json();

if(result==='valid'){
    window.location.href = "admin-dashboard.html";

} else {
document.getElementById("message").textContent = result;
}
}