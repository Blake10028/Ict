<?php
$db = new SQLite3('exam.db', SQLITE3_OPEN_CREATE | SQLITE3_OPEN_READWRITE);

if(!empty($_POST['register'])) {
   
}

if(isset($_POST['username']) && isset($_POST['password'])) {

}

