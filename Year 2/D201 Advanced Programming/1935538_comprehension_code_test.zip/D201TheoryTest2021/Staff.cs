using System;

public sealed class Staff : Person
{
    public Staff()
    {
        Email = "unknown EM";
    }

    public override string ToString()
    {
        return base.ToString() + " - " + Email + " - " + Age;
    }

    private string email;



    public string Email
    {
        get
        {
            return email;
        }
        set
        {
            email = value;
        }
    }

    public override string GetTitle()
    {
        return "Staff: " + FirstName[0] + ". " + LastName;
    }

}