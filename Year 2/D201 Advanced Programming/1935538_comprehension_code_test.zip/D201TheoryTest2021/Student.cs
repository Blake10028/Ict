using System;

public sealed class Student : Person
{
   
    public Student()
    {
        Course = "Unkown CO";
     
    }

    public override string ToString()
    {
        return base.ToString() + " - " + Course + " - " + Age;
    }

 private string course;

    public string Course
    {
        get
        {
            return course;
        }
        set
        {
            course = value;
        }
    }

    public override string GetDescription()
    {
        return base.GetDescription() + " " + Course;
    }

    public override string GetTitle()
    {
        return Course + " Student: " + FirstName[0] + ". " + LastName;
    }
   

}