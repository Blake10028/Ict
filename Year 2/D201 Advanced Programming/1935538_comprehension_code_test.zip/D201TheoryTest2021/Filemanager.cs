﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace D201TheoryTest2021
{
    class Filemanager
    {
        // This method is used to load staff data from a file and return a list of Staff
        public List<Staff> Loadstaff()
        {
            List<Staff> StaffList = new List<Staff>();

            // Open the text file Staff in read mode
            StreamReader Staffreader = new StreamReader("Staff.txt", true);

            // Read each line in the Staff file until the end
            while (!Staffreader.EndOfStream)
            {
                // Split each line by comma and store the values in an array
                string[] line = Staffreader.ReadLine().Split(',');

                // Create a new Staff object
                Staff staff = new Staff();

                // Assign the values from the array to the properties of the Staff object
                staff.FirstName = line[0];
                staff.LastName = line[1];
                staff.Email = line[2];
                staff.Age = int.Parse(line[3]);

                // Add the Staff object to the StaffList
                StaffList.Add(staff);
            }

            // Close the file
            Staffreader.Close();

            // Return the list of Staff
            return StaffList;
        }

        // This method is used to load student data from a file and return a list of Student
        public List<Student> Loadstudents()
        {
            List<Student> StudentList = new List<Student>();

            // Open the text file Students in read mode
            StreamReader Studentreader = new StreamReader("Students.txt", true);

            // Read each line in the students file until the end
            while (!Studentreader.EndOfStream)
            {
                // Split each line by comma and store the values in an array
                string[] line = Studentreader.ReadLine().Split(',');

                // Create a new Student object
                Student astudent = new Student();

                // Assign the values from the array to the properties of the Student object
                astudent.FirstName = line[0];
                astudent.LastName = line[1];
                astudent.Course = line[2];
                astudent.Age = int.Parse(line[3]);

                // Add the Student object to the StudentList
                StudentList.Add(astudent);
            }

            // Close the file
            Studentreader.Close();

            // Return the list of Student
            return StudentList;
        }
    }
}

