﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BasicInheritance;

namespace D201TheoryTest2021
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        List<Person> MixedList = new List<Person>();
        List<DepartmentSort> department = new List<DepartmentSort>();
        

        private void Load_Staff(object sender, RoutedEventArgs e)
        {


            listbox.Items.Clear();
            MixedList.Clear();
            Filemanager filemanager = new Filemanager();
            List<Staff> staff = new List<Staff>();
            staff = filemanager.Loadstaff();

            foreach (Staff s in staff)
            {
                MixedList.Add(s);
            }
            Updatelistbox();


        }

        private void Load_Student(object sender, RoutedEventArgs e)
        {
            listbox.Items.Clear();
            MixedList.Clear();
            Filemanager filemanager = new Filemanager();
            List<Student> students = new List<Student>();
            students = filemanager.Loadstudents();

            foreach (Student s in students)
            {
                MixedList.Add(s);
            }
            Updatelistbox();
        }

        private void Load_All(object sender, RoutedEventArgs e)
        {
            listbox.Items.Clear();
            MixedList.Clear();
            Filemanager filemanager = new Filemanager();
            List<Student> students = new List<Student>();
            List<Staff> staff = new List<Staff>();
            students = filemanager.Loadstudents();
            staff = filemanager.Loadstaff();

            foreach (Student s in students)
            {
                MixedList.Add(s);
            }
            foreach (Staff s in staff)
            {
                MixedList.Add(s);
            }
            Updatelistbox();
        }
        private void Updatelistbox()
        {
            listbox.ItemsSource =null;
            foreach (Person a in MixedList)
            {
                listbox.Items.Add(a);
            }
        }

        private void Load_Descriptions(object sender, RoutedEventArgs e)
        {
            listbox.Items.Clear();
            Filemanager filemanager = new Filemanager();

            MixedList.Clear();
            MixedList.AddRange(filemanager.Loadstaff().ToArray());
            MixedList.AddRange(filemanager.Loadstudents().ToArray());

            foreach (Person p in MixedList)
            {
                listbox.Items.Add(p.GetDescription());
            }
        }

        private void Load_Departments(object sender, RoutedEventArgs e)
        {
            department.Clear();
            DepartmentSort d1 = new DepartmentSort("Leanna Burnett", "Humanities and Business", 15);
            DepartmentSort d2 = new DepartmentSort("Roopak Sinha", "Design and Creative Technologies", 8);
            DepartmentSort d3 = new DepartmentSort("Chengfei Liu", "Software Engineering", 18);
            DepartmentSort d4 = new DepartmentSort("Ajay Narayan", "Engineering and Mathematical Sciences", 25);
            DepartmentSort d5 = new DepartmentSort("Raymond Chris", "Applied Sciences", 5);
            department.Add(d1);
            department.Add(d2);
            department.Add(d3);
            department.Add(d4);
            department.Add(d5);
            listbox.Items.Clear();
            foreach (DepartmentSort d in department)
            {
                listbox.Items.Add(d);
            }
        }

        private void Sort_Departments(object sender, RoutedEventArgs e)
        {

            department.Sort();
            listbox.Items.Clear();
            foreach (DepartmentSort d in department)
            {
                listbox.Items.Add(d);
            }


        }

        private void Save_All(object sender, RoutedEventArgs e)
        {
            // Retrieve the department objects from the listbox
            List<DepartmentSort> departmentList = new List<DepartmentSort>();
            foreach (DepartmentSort d in listbox.Items)
            {
                departmentList.Add(d);
            }

            // Save the department objects to a file
            SaveDepartmentList(departmentList);

            
        }

        private void SaveDepartmentList(List<DepartmentSort> departmentList)
        {
      

            // save to a text file
            using (StreamWriter writer = new StreamWriter("departmentData.txt"))
            {
                foreach (DepartmentSort department in departmentList)
                {
                    writer.WriteLine(department.ToString());
                }
            }
        }

        private void Sort_Students(object sender, RoutedEventArgs e)
        {
            // Retrieve the student objects from the MixedList
            List<Student> studentList = MixedList.OfType<Student>().ToList();

            // Sort the student objects by name
            studentList.Sort((s1, s2) => string.Compare(s1.FirstName, s2.FirstName));

            // Clear the listbox
            listbox.Items.Clear();

            // Add the sorted student objects to the listbox
            foreach (Student student in studentList)
            {
                listbox.Items.Add(student);
            }
        }


    }
}
