using System;

public abstract class Person
{

    public override string ToString()
    {
        return FirstName + " - " + LastName;
    }

    public Person()
    {
        FirstName = "unknown FN";
        LastName = "unknown LN";
        Age = 0;
    }

    private string firstName;

    public string FirstName
    {
        get
        {
            return firstName;
        }
        set
        {
            firstName = value;
        }
    }

    private string lastName;

    public string LastName
    {
        get
        {
            return lastName;
        }
        set
        {
            lastName = value;
        }
    }

    private int age;

    public int Age
    {
        get
        {
            return age;
        }
        set
        {
            age = value;
        }
    }

    public virtual string GetDescription()
    {
        return FirstName + " " + LastName + " " + Age;
    }

    public abstract string GetTitle();

}