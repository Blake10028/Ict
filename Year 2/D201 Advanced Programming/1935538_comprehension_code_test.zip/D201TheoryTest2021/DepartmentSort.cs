﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D201TheoryTest2021
{
    class DepartmentSort : IComparable<DepartmentSort>
    {
        //variables that hold the name of head of the department, department title and serviceage
        string HOD;
        string DepartmentTitle;
        int ServiceAge;
        public int CompareTo(DepartmentSort other)
        {
            return this.ToString().CompareTo(other.ToString());
        }
        public DepartmentSort(string hod, string c, int sa)
        {
            HOD = hod;           
            DepartmentTitle = c;
            ServiceAge = sa;
        }
        public override string ToString()
        {
            return HOD + " - "+ DepartmentTitle + " - " + ServiceAge.ToString();
        }
    }
}
