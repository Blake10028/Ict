﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace fruitstore_1935538
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        string usernamedatabase;
        string usernametextbox;
        string passwordtextbox;

        public LoginPage()
        {
            InitializeComponent();
        }

        private void LoginButton(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(UserNameTextBox.Text) && (!string.IsNullOrEmpty(PasswordTextBoxShown.Text) || !string.IsNullOrEmpty(PasswordTextBoxHidden.Password)))
            {
                try
                {
                    SqlConnection con = new SqlConnection(Properties.Settings.Default.GeneratePath());

                    con.Open();

                    usernametextbox = UserNameTextBox.Text;
                    passwordtextbox = PasswordTextBoxHidden.Password;

                    string queryusername = "SELECT UserName,Password FROM Employee WHERE ( UserName = @CompareCaseUserName AND Password = @PasswordFromTextBox)";

                    SqlCommand sqlCommand = new SqlCommand(queryusername, con);

                    int result = 0;

                    sqlCommand.CommandType = CommandType.Text;

                   
                    sqlCommand.Parameters.Add("CompareCaseUserName", SqlDbType.NVarChar).Value = usernametextbox;
                    sqlCommand.Parameters.Add("PasswordFromTextBox", SqlDbType.NVarChar).Value = passwordtextbox;
                    



                    using (SqlDataReader sqlreader = sqlCommand.ExecuteReader())
                    {
                        if (sqlreader.Read())
                        {
                            usernamedatabase = sqlreader.GetValue(0).ToString();
                            

                            result = String.Compare(usernamedatabase, usernametextbox);

                            if (result == 0)
                            {
                                if ( usernametextbox == "Cs101")
                                {
                                    MessageBox.Show("Welcome Manager");
                                    WriteUserNameToTextFile();
                                    this.NavigationService.Navigate(new ManagerPage());
                                }
                                else
                                {
                                    MessageBox.Show("Welcome Cashier " + usernametextbox);
                                    WriteUserNameToTextFile();
                                    this.NavigationService.Navigate(new StaffPage());
                                }
                            }
                            else
                            {

                                MessageBox.Show("Correct Username but field is Case Sensitive. Try again with appropriate Cases", "TextBox is Case Sensistive");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Wrong Login");
                        }
                    }

                    con.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occured --> " + ex);
                }


            }
            else
            {
                MessageBox.Show("All Fields must filled. It is Compulsory");
            }

        }

        private void ShowPasswordUnchecked(object sender, RoutedEventArgs e)
        {
            PasswordTextBoxHidden.Password = PasswordTextBoxShown.Text;
            PasswordTextBoxHidden.Visibility = Visibility.Visible;
            PasswordTextBoxShown.Visibility = Visibility.Collapsed;
        }

        private void ShowPasswordChecked(object sender, RoutedEventArgs e)
        {
            PasswordTextBoxShown.Text = PasswordTextBoxHidden.Password;
            PasswordTextBoxHidden.Visibility = Visibility.Collapsed;
            PasswordTextBoxShown.Visibility = Visibility.Visible;

        }

        public void WriteUserNameToTextFile()
        {
            if (File.Exists("UserName.txt"))
            {
                File.Delete("UserName.txt");
            }
            StreamWriter sw = new StreamWriter("UserName.txt", true);

            sw.WriteLine(usernametextbox.ToString());

            sw.Close();

        }


    }
}
