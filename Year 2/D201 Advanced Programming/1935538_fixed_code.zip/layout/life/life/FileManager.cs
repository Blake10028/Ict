﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace life
{
    internal class FileManager
    {
       
        public List<DataClass> PlaneList = new List<DataClass>();

        
        public List<DataClass> LoadPlane(string FileName)
        {
            PlaneList.Clear();
            string line;

            StreamReader PlaneFileReader = new StreamReader(FileName);
            while ((line = PlaneFileReader.ReadLine()) != null)
            {
                string[] planeInfo = { "Name", "Type", "Speed", "Position" };
                planeInfo = line.Split('|');

                PlaneList.Add(new DataClass(planeInfo[0], planeInfo[1], planeInfo[2], planeInfo[3], planeInfo[4]));
            }

            PlaneFileReader.Close();
            return PlaneList;
        }

        public List<DataClass> SaveList(List<DataClass> PlaneList2)
        {
            StreamWriter PlaneFileWriter = new StreamWriter("PreviousList.txt");

            for (int i = 0; i < PlaneList2.Count; i++)
            {
                string planeLine = PlaneList2[i].firstName.ToString() + "|" + PlaneList2[i].type.ToString() + "|" + PlaneList2[i].speed + "|" + PlaneList2[i].positionX + "|" + PlaneList2[i].positionY;
                PlaneFileWriter.WriteLine(planeLine);
            }
            PlaneFileWriter.Close();
            return PlaneList2;
        }

    }
}
