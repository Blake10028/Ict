﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace life
{
    internal class DataClass
    {
        //declares variables for MyClass
        public string firstName;
        public string type;
        public string speed;
        public string positionX;
        public string positionY;

        public string Name
        {
            //returns and assigns value to Variable "Name"
            get { return firstName; }
            set { firstName = value; }
        }
        public string Type
        //returns and assigns value to Variable "Type"
        {
            get { return type; }
            set { type = value; }
        }
        public string Speed
        {
            //returns and assigns value to Variable "Speed"
            get { return speed; }
            set { speed = value; }
        }
        public string PositionX
        {
            //returns and assigns value to Variable "PositionX"
            get { return positionX; }
            set { positionX = value; }
        }
        public string PositionY
        {
            //returns and assigns value to Variable "PositionY"
            get { return positionY; }
            set { positionY = value; }
        }
        public DataClass()
        {
            //gives default values for objects in class
            firstName = "unknown";
            Type = "unknown";
            Speed = "10";
            PositionX = "100";
            PositionY = "50";
        }
        public DataClass(string n, string t, string s, string x, string y)
        {
            //used to declare variables
            firstName = n;
            type = t;
            speed = s;
            positionX = x;
            positionY = y;
        }
        public override string ToString()
        {
            //converts objects to string
            return firstName + " | " + type + " | " + speed + " | " + "X: " + positionX + "Y: " + positionY;
        }
    }
    }

