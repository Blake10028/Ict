﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using System.Windows.Threading;

namespace life
{

    public partial class MainWindow : Window
    {

        List<DataClass> Planes;
        List<Image> PlanePics = new List<Image>();
        //creates list called planeList
        List<string> planeList = new List<string>();

        List<DataClass> searchRes;
        List<DataClass> tempSearch;
        List<int> speedListX;
        List<int> speedListY;


        int ShowStatus = -1;
        int imagePositionX;
        int imagePositionY;

        //creates timer
        DispatcherTimer timer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();


            Planes = new List<DataClass>();
            speedListX = new List<int>();
            speedListY = new List<int>();

            timer.Tick += new EventHandler(timer_TickX); // calling the event handler to move the image
            timer.Interval = new TimeSpan(0, 0, 0, 0, 40); // setting the time interval
            timer.Start(); //starting the timer
        }

        void timer_TickX(object sender, EventArgs e)
        {

            for (int i = 0; i < mainCanvas.Children.Count; i++)
            {
                imagePositionX = Convert.ToInt32(PlanePics[i].GetValue(Canvas.LeftProperty));
                imagePositionY = Convert.ToInt32(PlanePics[i].GetValue(Canvas.TopProperty));

                int varX = speedListX[i];
                int varY = speedListY[i];


                if (imagePositionX <= 380 && imagePositionX >= 10)
                {

                    Canvas.SetLeft(PlanePics[i], imagePositionX + varX);
                    imagePositionX = Convert.ToInt32(PlanePics[i].GetValue(Canvas.LeftProperty));

                }

                else if (imagePositionX > 380 || imagePositionX < 10)
                {
                    speedListX[i] = varX * -1;
                    varX = speedListX[i];
                    Canvas.SetLeft(PlanePics[i], imagePositionX + varX);
                    imagePositionX = Convert.ToInt32(PlanePics[i].GetValue(Canvas.LeftProperty));

                }

                if (imagePositionY <= 355 && imagePositionY >= 4)
                {

                    Canvas.SetTop(PlanePics[i], imagePositionY + varY);
                    imagePositionY = Convert.ToInt32(PlanePics[i].GetValue(Canvas.TopProperty));
                }

                else if (imagePositionY > 355 || imagePositionY < 4)
                {
                    speedListY[i] = varY * -1;
                    varY = speedListY[i];
                    Canvas.SetTop(PlanePics[i], imagePositionY + varY);
                    imagePositionY = Convert.ToInt32(PlanePics[i].GetValue(Canvas.TopProperty));
                }

                if (ShowStatus == 1)
                {

                    tempSearch[i].positionX = imagePositionX.ToString();
                    tempSearch[i].positionY = imagePositionY.ToString();
                    planeList[i + 1] = (tempSearch[i].ToString());
                    list.ItemsSource = planeList.ToArray();
                }
            }
        }

        //calls onto Class called "File Manager"
        FileManager fileManager = new FileManager();



        private void show_status(object sender, RoutedEventArgs e)
        {
            //Toggles "ShowStatus" between -1, and 1; eg ON & OFF
            ShowStatus = ShowStatus * -1;
            //if statement to toggle button colour, to show if running or not
            if (ShowStatus == 1)
            {
                Toggle.Background = Brushes.LightSlateGray;
            }
            else
            {
                Toggle.Background = Brushes.LightGray;
            }
        }

        private void remove_select_plane(object sender, RoutedEventArgs e)
        {
            try
            {
                //removes all neccesary parts to remove image, speed, and object on listbox selected index
                planeList.RemoveAt(list.SelectedIndex);
                mainCanvas.Children.RemoveAt((list.SelectedIndex - 1));
                PlanePics.RemoveAt(list.SelectedIndex - 1);
                speedListX.RemoveAt(list.SelectedIndex - 1);
                speedListY.RemoveAt(list.SelectedIndex - 1);
                tempSearch.RemoveAt(list.SelectedIndex - 1);
                //puts planeList into listbox
                list.ItemsSource = planeList.ToArray();
            }
            catch
            {
                //Error message if object not selected
                MessageBox.Show("You cannot delete this item", "Error");
            }
        }

        private void seach_by_type(object sender, RoutedEventArgs e)
        {

            Filter Searcher = new Filter();

            string searchFor = textbox2.Text;

            searchRes = Searcher.Search(Planes, searchFor);
            tempSearch = searchRes;
            UpdateListBox();
        }

        private void Load_data(object sender, RoutedEventArgs e)
        {
            //clears Planes Variable
            Planes.Clear();
            //Fills Planes Variable with List returned from planeList.txt file
            Planes = fileManager.LoadPlane("PlaneList.txt");
            //sets temp search as plane variable
            tempSearch = Planes;
            //calls on method: Updates listbox
            UpdateListBox();
        }

        private void Sort_By_Type_Z_A(object sender, RoutedEventArgs e)
        {
            //calls on "Filter" class
            Filter PlaneSorterZA = new Filter();
            //calls on SortZA method, uses tempSearch: Sorts tempSearch by Z-A
            tempSearch = PlaneSorterZA.SortZA(tempSearch);
            //calls on method: Updates listbox
            UpdateListBox();
        }

        private void UpdateListBox()
        {

            planeList.Clear();
            mainCanvas.Children.Clear();
            speedListX.Clear();
            speedListY.Clear();


            planeList.Add("Name:   | Type:    | Speed:   | Position:");
            for (int i = 0; i < tempSearch.Count; i++)
            {

                Image planeImage = new Image();
                PlanePics.Add(planeImage);

                planeList.Add(tempSearch[i].ToString());
                mainCanvas.Children.Add(PlanePics[i]);
                PlanePics[i].Source = new BitmapImage(new Uri((tempSearch[i].type + ".png"), UriKind.Relative));
                Canvas.SetLeft(PlanePics[i], Int16.Parse(tempSearch[i].positionX));
                Canvas.SetTop(PlanePics[i], Int16.Parse(tempSearch[i].positionY));
                PlanePics[i].Width = 120;
                speedListX.Add(Convert.ToInt32(tempSearch[i].speed));
                speedListY.Add(Convert.ToInt32(tempSearch[i].speed));
            }

            list.ItemsSource = planeList.ToArray();
        }

        private void Save_Current_List(object sender, RoutedEventArgs e)
        {
            // saves current list to file located in Filemanager.SaveList Method
            tempSearch = fileManager.SaveList(tempSearch);
        }

        private void Load_Previous_Saving(object sender, RoutedEventArgs e)
        {
            Planes.Clear();
            //Loads lines from File "PreviousList.txt" and stores in variable planes
            Planes = fileManager.LoadPlane("PreviousList.txt");
            tempSearch = Planes;
            UpdateListBox();
        }

        private void Sort_By_Type_A_Z(object sender, RoutedEventArgs e)
        { 
            Filter PlaneSorterAZ = new Filter();
            tempSearch = PlaneSorterAZ.SortAZ(tempSearch);
            UpdateListBox();
        }

        private void Clear(object sender, RoutedEventArgs e)
        {
            //Clears List Box
            list.ItemsSource = null;
            //removes Images
            mainCanvas.Children.Clear();
        }
    }
}
