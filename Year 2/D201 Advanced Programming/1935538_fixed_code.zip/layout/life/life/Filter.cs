﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace life
{
    internal class Filter
    {
        public List<DataClass> SortAZ(List<DataClass> theplanetype)
        {
            theplanetype = (from n in theplanetype
                            orderby n.type, n.firstName
                          select n).ToList();
            return theplanetype;
        }

        public List<DataClass> SortZA(List<DataClass> theplanetype)
        {
            theplanetype = (from n in theplanetype
                            orderby n.type descending, n.firstName
                          select n).ToList();
            return theplanetype;
        }

        public List<DataClass> Search(List<DataClass> thePlane, string term)
        {
            List<DataClass> searchResults = new List<DataClass>();
            searchResults = thePlane.Where(x => x.type.Contains(term)).ToList();
            return searchResults;
        }
    }
}
